package ua.com.cruises.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ua.com.cruises.controller.uris.AppPath;
import ua.com.cruises.model.User;
import ua.com.cruises.repository.OrderDao;
import ua.com.cruises.repository.UserDao;

import java.io.IOException;

@WebServlet(AppPath.PATH_TO_USER_PROFILE)
public class UserProfile extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user;
        if (req.getParameter("user") != null && UserDao.getInstance().isUsernameExists(req.getParameter("user"))) {
            user = UserDao.getInstance().find(req.getParameter("user")).get();
        } else {
            user = (User) req.getSession().getAttribute("user");
        }

        if (user != null && user.getId() != 0) {
            req.setAttribute("images", UserDao.getInstance().findUserImagesByObj(user));
            req.setAttribute("orders", OrderDao.getInstance().findByUser(user));
        }

        req.getRequestDispatcher("jsp/user-profile.jsp").forward(req, resp);
    }
}
