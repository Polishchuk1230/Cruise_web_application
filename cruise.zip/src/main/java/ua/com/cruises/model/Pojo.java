package ua.com.cruises.model;

public interface Pojo {

    int getId();

    void setId(int id);
}
