package ua.com.cruises.model;

public enum CruiseStatus {
    REGISTRATION_IN_PROGRESS, REGISTRATION_CLOSED, IN_PROGRESS, COMPLETED
}
