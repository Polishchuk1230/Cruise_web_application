package ua.com.cruises.model;

public enum Role {
    USER, ADMIN
}
